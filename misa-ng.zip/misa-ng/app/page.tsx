import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Properties from "@/components/Properties";
import LeadModal from "@/components/LeadModal";
import LeadButton from "@/components/LeadButton";
import Reveal from "@/components/Reveal";
import { news } from "@/lib/data";

const pillars = [
  ["Property listings", "Residential, commercial and land listings, checked before they reach you."],
  ["Real estate and finance news", "Market notes, mortgage options and policy changes that affect your deal."],
  ["Developer onboarding", "Put your project in front of qualified buyers and investors."],
  ["Investment", "Structured opportunities, with MISA paid by commission on completion."],
];

export default function Home() {
  const wa = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "";
  return (
    <main>
      <Navbar />
      <Hero />
      <section className="border-y border-line bg-navy">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-16 md:grid-cols-2 lg:grid-cols-4">
          {pillars.map(([t, b], i) => (
            <Reveal key={t} delay={i * 80}><h3 className="font-serif text-xl">{t}</h3><p className="mt-3 text-sm leading-relaxed text-soft">{b}</p></Reveal>
          ))}
        </div>
      </section>

      <section id="invest" className="grid lg:grid-cols-2">
        <div className="min-h-[420px] bg-[linear-gradient(150deg,#F59A16,#A85F08_55%,#050505)]" aria-hidden />
        <div className="bg-panel px-8 py-20 lg:px-16">
          <Reveal>
            <p className="text-sm text-gold">Featured development</p>
            <h2 className="mt-3 font-serif text-4xl">Maitama Terraces</h2>
            <p className="mt-5 max-w-md leading-relaxed text-soft">A gated terrace community in Abuja with 4-bedroom homes, private parking and title documents ready for transfer.</p>
            <dl className="mt-8 flex gap-12"><div><dt className="text-xs text-muted">Price from</dt><dd className="font-serif text-2xl">N450m</dd></div><div><dt className="text-xs text-muted">Bedrooms</dt><dd className="font-serif text-2xl">4</dd></div></dl>
            <div className="mt-8"><LeadButton type="Investment pack: Maitama Terraces">Request the investment pack</LeadButton></div>
          </Reveal>
        </div>
      </section>

      <Properties />

      <section id="developers" className="bg-navy">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-24 lg:grid-cols-2">
          <Reveal>
            <p className="text-sm text-gold">For developers</p>
            <h2 className="mt-3 font-serif text-4xl">A direct route to buyers and investors.</h2>
            <p className="mt-5 max-w-md leading-relaxed text-soft">We list your development, qualify the enquiries and introduce serious buyers. You pay commission only when a sale completes.</p>
          </Reveal>
          <Reveal delay={150} className="flex flex-col items-start justify-center gap-4">
            <LeadButton type="Developer onboarding">Start onboarding</LeadButton>
            <p className="text-sm text-muted">Share your project details and an agent will reply with next steps.</p>
          </Reveal>
        </div>
      </section>

      <section id="newsfeed" className="mx-auto max-w-7xl px-6 py-24">
        <div className="flex flex-wrap items-end justify-between gap-6 border-b border-line pb-6">
          <h2 className="max-w-xl font-serif text-4xl">Market notes and buyer insights</h2>
          <LeadButton type="Newsfeed subscription" className="btn-line">Subscribe to the newsfeed</LeadButton>
        </div>
        <ul className="mt-4 divide-y divide-line">
          {news.map((n) => (
            <li key={n.title} className="py-6"><p className="text-xs text-muted">{n.tag}</p><p className="mt-1 font-serif text-2xl">{n.title}</p></li>
          ))}
        </ul>
      </section>

      <footer id="contact" className="border-t border-line bg-navy">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 py-16 md:grid-cols-[1.4fr_1fr_1fr]">
          <div>
            <p className="font-serif text-2xl">Municipal Integrated Service Agent NG Ltd</p>
            <p className="mt-3 max-w-sm text-sm text-soft">MISA NG LTD is part of Strategic Infrastructure and Resource Partners (SIR-Partners).</p>
            <div className="mt-6"><LeadButton type="Contact request">Contact us</LeadButton></div>
          </div>
          <nav className="grid content-start gap-3 text-sm text-soft">
            <a href="#properties" className="hover:text-brand">Properties</a><a href="#invest" className="hover:text-brand">Invest</a><a href="#newsfeed" className="hover:text-brand">Newsfeed</a>
          </nav>
          <nav className="grid content-start gap-3 text-sm text-soft">
            <a href="#developers" className="hover:text-brand">Developers</a><a href="#top" className="hover:text-brand">Back to top</a>
          </nav>
        </div>
        <p className="border-t border-line px-6 py-6 text-center text-xs text-muted">&copy; {new Date().getFullYear()} MISA NG LTD. All rights reserved.</p>
      </footer>

      {wa && (
        <a href={`https://wa.me/${wa}?text=${encodeURIComponent("Hello MISA NG, I would like to enquire about a property.")}`} target="_blank" rel="noopener noreferrer"
          aria-label="Chat on WhatsApp" className="fixed bottom-6 right-6 z-30 grid h-14 w-14 place-items-center rounded-full bg-profit text-ink shadow-lg transition hover:scale-105">
          <svg viewBox="0 0 24 24" className="h-7 w-7" fill="currentColor"><path d="M12 2a10 10 0 0 0-8.6 15l-1.3 4.9 5-1.3A10 10 0 1 0 12 2Zm5.2 14c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.2-4.6-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8s.7-2 .9-2.300c.2-.300.5-.300.700-.300h.500c.200 0 .400 0 .600.500l.800 2c.100.200.100.400 0 .500l-.400.600c-.1.100-.3.300-.1.600.6 1 1.400 1.800 2.400 2.300.3.100.500.100.600-.1l.800-1c.200-.200.400-.200.600-.100l1.900.9c.2.100.4.200.4.300.100.200.100.800-.100 1.400Z" /></svg>
        </a>
      )}
      <LeadModal />
    </main>
  );
}
